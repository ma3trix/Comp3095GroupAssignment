rootProject.name = "friendship-service"
