package ca.gbc.friendshipservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendshipServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
