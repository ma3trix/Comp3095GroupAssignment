rootProject.name = "springsocial-microservices-parent"
